﻿using System;

namespace SecondOption
{
    public class Class1
    {
    }
}
