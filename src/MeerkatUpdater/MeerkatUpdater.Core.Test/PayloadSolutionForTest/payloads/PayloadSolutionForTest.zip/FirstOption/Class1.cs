﻿using System;

namespace FirstOption
{
    public class Class1
    {
    }
}
